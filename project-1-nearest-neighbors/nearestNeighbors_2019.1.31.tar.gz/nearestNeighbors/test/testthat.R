library(testthat)
test_check("nearestNeighbors")

